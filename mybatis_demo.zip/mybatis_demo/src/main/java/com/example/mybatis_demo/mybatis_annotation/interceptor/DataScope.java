package com.example.mybatis_demo.mybatis_annotation.interceptor;

import java.util.HashMap;

/**
 * 数据查询
 */
public class DataScope extends HashMap {
}
